/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.eva;

import javax.faces.bean.ManagedBean;

/**
 *
 * @author HP
 */
@ManagedBean(name="employee1")
public class Employee1 {
     private  String name;
  private int id;
  private String email;
  private String position;

    public Employee1() {
        
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }
 public String Submit(){
      return "Result.jsp";
  }
  
}
